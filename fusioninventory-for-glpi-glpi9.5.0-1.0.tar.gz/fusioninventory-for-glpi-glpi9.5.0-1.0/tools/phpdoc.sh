phpdoc -d ../ -t dev-docs/ --ignore "phpunit*","lib*","tools*","scripts*" --force --title "Plugin FusionInventory for GLPI code documentation"
